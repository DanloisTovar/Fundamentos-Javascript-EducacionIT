var fecha = new Date();

var ref = document.getElementById('titulo');
ref.innerHTML = fecha; //'Te pisé';
ref.style.color = 'white';
ref.style.backgroundColor = 'black';
ref.style.padding = '10px';
ref.style.borderRadius = '12px';

